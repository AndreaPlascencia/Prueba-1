/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import DAO.DAOException;
import DAO.IExhibicionDAO;
import Modelo.Exposicion;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Andrea Plascencia
 */
public class ExposicionesObraTableModel extends AbstractTableModel {
    //Propiedades
    private IExhibicionDAO exhibicion;
    
    //Lista de elementos de tipo Exposicion
    private List<Exposicion> datosExhibicion = new ArrayList<>();
    
    //Se da formato a la variable de tipo Date 
    SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yyyy");
    
    //Constructor
    public ExposicionesObraTableModel (IExhibicionDAO exhibicion) {
        this.exhibicion = exhibicion;
    }
    
    /**
     * Retorna el nombre de cada columna de la tabla exposicion
     * @param column
     * @return 
     */
    @Override
    public String getColumnName (int column) {
        switch(column) {
            case 0: return "ID Exposición";
            case 1: return "ID Galería";
            case 2: return "Título de la Exposición";
            case 3: return "Fecha de Inicio";
            case 4: return "Fecha de Fin";
            default: return "[no]";
        }
    }
    
    /**
     * Retorna el número de elementos obtenidos de la tabla exposicion
     * @return 
     */
    @Override
    public int getRowCount() {
        return datosExhibicion.size();
    }
    
    /**
     * Retorna el número de columnas
     * @return 
     */
    @Override
    public int getColumnCount() {
        return 5;
    }

    /**
     * Retorna el valor de alguna intersección
     * @param rowIndex
     * @param columnIndex
     * @return 
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Exposicion preguntado = datosExhibicion.get(rowIndex);
        switch (columnIndex) {
            case 0: return preguntado.getIdExposicion();
            case 1: return preguntado.getIdGaleria();
            case 2: return preguntado.getTituloExposicion();
            case 3: return formato.format(preguntado.getFechaInicio());
            case 4: return formato.format(preguntado.getFechaFinal());
            default: return "";
        }
    }
    
    /**
     * Muestra una lista de las exposiciones de una obra
     * @param idObra
     * @throws DAOException 
     */
    public void updateModel(int idObra) throws DAOException {
        this.datosExhibicion = exhibicion.obtenerExposicionesDeLaObra(idObra);
    }
    
}//Fin de la clase ExposicionesObraTableModel
