/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySQL;

import DAO.DAOManager;
import DAO.IAutorDAO;
import DAO.IExhibicionDAO;
import DAO.IExposicionDAO;
import DAO.IGaleriaDAO;
import DAO.IObraDAO;
import DAO.IUsuarioDAO;

/**
 *
 * @author Andrea Plascencia
 */
public class MySQLDAOManager implements DAOManager {
    
    private IUsuarioDAO usuario = null;
    private IAutorDAO autor = null;
    private IObraDAO obra = null;
    private IGaleriaDAO galeria = null;
    private IExposicionDAO exposicion = null;
    private IExhibicionDAO exhibicion = null;
    
    //Métodos para reutilizar objetos (Patrón Singleton)
    
    @Override
    public IUsuarioDAO getUsuarioDAO() {
        if (usuario == null) {
            usuario = new MySQLUsuarioDAO();
        }
        return usuario;
    }//Fin del método getUsuarioDAO

    @Override
    public IAutorDAO getAutorDAO() {
        if (autor == null) {
            autor = new MySQLAutorDAO();
        }
        return autor;
    }//Fin del método getAutorDAO

    @Override
    public IObraDAO getObraDAO() {
        if (obra == null) {
            obra = new MySQLObraDAO();
        }
        return obra;
    }//Fin del método getObraDAO

    @Override
    public IGaleriaDAO getGaleriaDAO() {
        if (galeria == null) {
            galeria = new MySQLGaleriaDAO();
        }
        return galeria;
    }//Fin del método getGaleriaDAO

    @Override
    public IExposicionDAO getExposicionDAO() {
        if (exposicion == null) {
            exposicion = new MySQLExposicionDAO();
        }
        return exposicion;
    }//Fin del método getExposicionDAO

    @Override
    public IExhibicionDAO getExhibicionDAO() {
        if (exhibicion == null) {
            exhibicion = new MySQLExhibicionDAO();
        }
        return exhibicion;
    }//Fin del método getExhibicionDAO
    
}//Fin de la clase MySQLDAOManager
