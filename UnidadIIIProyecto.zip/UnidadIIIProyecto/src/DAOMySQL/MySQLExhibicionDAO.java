/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySQL;

import DAO.DAOException;
import DAO.IExhibicionDAO;
import Modelo.Exhibicion;
import Modelo.Exposicion;
import Modelo.Obra;
import MySQLConexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 *
 * @author Andrea Plascencia
 */
public class MySQLExhibicionDAO implements IExhibicionDAO {
    
    //Propiedades para el acceso a la base de datos
    private Connection conn;
    private ResultSet rs;
    private PreparedStatement ps;
    
    //Consultas SQL
    private final String INSERT = "INSERT INTO exhibicion (exhibicion.idObra,"
            + " exhibicion.idExposicion)"
            + " VALUES (?, ?)";
    
    private final String DELETE = "DELETE FROM exhibicion WHERE"
            + " idObra = ? AND idExposicion = ?";
    
    private final String GETALLARTWORKSBYEXPOSITION = "SELECT obra.idObra,"
            + " idAutor, tituloObra, corrienteArtistica, tecnica, anio FROM obra"
            + " INNER JOIN exhibicion ON obra.idObra = exhibicion.idObra"
            + " INNER JOIN exposicion ON exhibicion.idExposicion = exposicion.idExposicion"
            + " WHERE exposicion.idExposicion = ?";
    
    private final String GETALLEXPOSITIONSOFTHEARTWORKS = "SELECT exposicion.idExposicion,"
            + " idGaleria, tituloExposicion, fechaInicio, fechaFinal FROM exposicion"
            + " INNER JOIN exhibicion ON exposicion.idExposicion = exhibicion.idExposicion"
            + " INNER JOIN obra ON obra.idObra = exhibicion.idObra WHERE obra.idObra = ?";
    
    /**
     * Método que obtiene las exposiciones donde estará la obra
     * @param idObra
     * @return
     * @throws DAOException 
     */
    @Override
    public List<Exposicion> obtenerExposicionesDeLaObra(int idObra) throws DAOException {
        List<Exposicion> misExposiciones = null;
        
        try {
            //Creamos el objeto que retornaremos
            misExposiciones = new ArrayList<Exposicion>();
            
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta
            ps = conn.prepareStatement(GETALLEXPOSITIONSOFTHEARTWORKS);
            ps.setInt(1, idObra);
            
            //Ejecutamos la consulta y almacenamos el resultado en un ResultSet
            rs = ps.executeQuery();
            
            //Recorremos el ResultSet y agregamos cada exposicion al ArrayList
            while (rs.next()) {
                Exposicion miExposicion = new Exposicion();
                miExposicion.setIdExposicion(rs.getInt("idExposicion"));
                miExposicion.setIdGaleria(rs.getInt("idGaleria"));
                miExposicion.setTituloExposicion(rs.getString("tituloExposicion"));
                miExposicion.setFechaInicio(rs.getDate("fechaInicio"));
                miExposicion.setFechaFinal(rs.getDate("fechaFinal"));
                misExposiciones.add(miExposicion);
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }
        
        return misExposiciones;
    }//Fin del método obtenerExposicionesDeLaObra
    
    /**
     * Método que obtiene las obras que estarán en una exposición
     * @param idExposicion
     * @return
     * @throws DAOException 
     */
    @Override
    public List<Obra> obtenerObrasPorExposicion(int idExposicion) throws DAOException {
        List<Obra> misObras = null;
        try {
            //Creamos la instanciación del parámetro a retornar
            misObras = new ArrayList<Obra>();
            
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta
            ps = conn.prepareStatement(GETALLARTWORKSBYEXPOSITION);
            ps.setInt(1, idExposicion);
            
            //Ejecutamos la consulta y almacenamos el resultado en un objeto ResultSet
            rs = ps.executeQuery();
            
            //Recorremos el ResultSet y agregamos cada item al ArrayList
            while (rs.next()) {
                Obra miObra = new Obra();
                miObra.setIdObra(rs.getInt("idObra"));
                miObra.setIdAutor(rs.getInt("idAutor"));
                miObra.setTituloObra(rs.getString("tituloObra"));
                miObra.setCorrienteArtistica(rs.getString("corrienteArtistica"));
                miObra.setTecnica(rs.getString("tecnica"));
                miObra.setAnio(rs.getString("anio"));
                misObras.add(miObra);
            }
        }catch(SQLException ex) {
            throw new DAOException ("Error en SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }
        
        return misObras;
    }//Fin del método obtenerObrasPorExposicion
    
    /**
     * Método que elimina la relación que hace una exhibición
     * @param exhibicion
     * @throws DAOException 
     */
    @Override
    public void eliminar(Exhibicion exhibicion) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta y especificamos los parámetros
            ps = conn.prepareStatement(DELETE);
            ps.setInt(1, exhibicion.getIdObra());
            ps.setInt(2, exhibicion.getIdExposicion());
            
            //Ejecutamos la consulta y verificamos el resultado
            if (ps.executeUpdate() == 0) {
                throw new DAOException("Hubo un problema y no se pudo eliminar"
                        + " el registro ");
            }
        }catch(SQLException ex) {
            throw new DAOException ("Error en SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }
    }//Fin del método eliminar
    
    /**
     * Método para insertar la relación entre obra y exposición
     * @param exhibicion
     * @throws DAOException 
     */
    @Override
    public void insertar(Exhibicion exhibicion) throws DAOException {
        try {
            
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta y especificamos los parámetros
            ps = conn.prepareStatement(INSERT);
            ps.setInt(1, exhibicion.getIdObra());
            ps.setInt(2, exhibicion.getIdExposicion());
            
            if (ps.executeUpdate() == 0) {
                throw new DAOException ("No se pudo guardar la relación"
                        + " entre obra y exposición ");
            }
            
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }
    }//Fin del metodo insertar
    
    /**
     * Método para crear un reporte
     * @param ruta
     * @param miParametro
     * @return
     * @throws DAOException 
     */
    @Override
    public JasperPrint crearReporte(String ruta, int miParametro) throws DAOException {
        //Objeto a retornar 
        JasperPrint jprint = null;
        
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            JasperReport reporte = null;
            Map parametro = new HashMap();
            parametro.put("idExposicion", miParametro);
            
            reporte = (JasperReport) JRLoader.loadObjectFromFile(ruta);
            jprint = JasperFillManager.fillReport(reporte, parametro, conn);

        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        } catch (JRException ex) {
            Logger.getLogger(MySQLExhibicionDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
        
        return jprint;
    }

    @Override
    public void modificar(Exhibicion a) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void eliminar(Integer id) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Exhibicion obtener(Integer id) throws DAOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void cerrarConexiones 
        (PreparedStatement ps, ResultSet rs, Connection conn) throws DAOException {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL", ex);
        }
    }//Fin del método cerrarConexiones
    
}//Fin de la clase MySQLExhibicion
