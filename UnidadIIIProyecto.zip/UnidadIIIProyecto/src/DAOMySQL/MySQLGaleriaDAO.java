/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySQL;

import DAO.DAOException;
import DAO.IGaleriaDAO;
import Modelo.Galeria;
import MySQLConexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Andrea Plascencia
 */
public class MySQLGaleriaDAO implements IGaleriaDAO {
    
    //Propiedades para controlar la base de datos
    private Connection conn = null;
    private ResultSet rs = null;
    private PreparedStatement ps = null;
    
    //Consultas SQL
    private final String INSERT = "INSERT INTO galeria (nombreGaleria, calle,"
            + " colonia, ciudad, estado, pais, codigoPostal)"
            + " VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    private final String UPDATE = "UPDATE galeria SET nombreGaleria = ?,"
            + " calle = ?, colonia = ?, ciudad = ?, estado = ?, pais = ?,"
            + " codigoPostal = ? WHERE idGaleria = ?";
    
    private final String DELETE = "DELETE FROM galeria WHERE idGaleria = ?";
    
    private final String GETONE = "SELECT idGaleria, nombreGaleria, calle,"
            + " colonia, ciudad, estado, pais, codigoPostal FROM galeria"
            + " WHERE idGaleria = ?";
    
    /**
     * Método para insertar una galería
     * @param galeria
     * @throws DAOException 
     */
    @Override
    public void insertar(Galeria galeria) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando los parámetros
            ps = conn.prepareStatement(INSERT,
                    PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, galeria.getNombreGaleria());
            ps.setString(2, galeria.getCalle());
            ps.setString(3, galeria.getColonia());
            ps.setString(4, galeria.getCiudad());
            ps.setString(5, galeria.getEstado());
            ps.setString(6, galeria.getPais());
            ps.setInt(7, galeria.getCodigoPostal());
            
            //Ejecutamos la cosulta y verificamos el resultado
            if (ps.executeUpdate() == 0) {
                throw new DAOException("No se pudo guardar la nueva galeria");
            }else {
                rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    galeria.setIdGaleria(rs.getInt(1));
                }else {
                    throw new DAOException("No se pudo "
                            + "asignar el ID a esta galeria");
                }
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método insertar
    
    /**
     * Método para modificar una galería
     * @param galeria
     * @throws DAOException 
     */
    @Override
    public void modificar(Galeria galeria) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando los parámetros de entrada
            ps = conn.prepareStatement(UPDATE);
            ps.setString(1, galeria.getNombreGaleria());
            ps.setString(2, galeria.getCalle());
            ps.setString(3, galeria.getColonia());
            ps.setString(4, galeria.getCiudad());
            ps.setString(5, galeria.getEstado());
            ps.setString(6, galeria.getPais());
            ps.setInt(7, galeria.getCodigoPostal());
            ps.setInt(8, galeria.getIdGaleria());
            
            //Ejecutamos la consulta y verificamos el resultado
            if (ps.executeUpdate() == 0) {
                throw new DAOException("Hubo un problema y no se guardaron"
                        + " los cambios");
            }
        }catch (SQLException ex) {
            throw new DAOException("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin del método modificar

    @Override
    public void eliminar(Integer idGaleria) throws DAOException {
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando parametros de entrada
            ps = conn.prepareStatement(DELETE);
            ps.setInt(1, idGaleria);
            
            //Ejecutamos la consulta y verificamos el resultado 
            if (ps.executeUpdate() == 0) {
                throw new DAOException("Hubo un problema y no se pudo eliminar"
                        + " el registro");
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
    }//Fin el método eliminar
    
    /**
     * Método para obtener una galería
     * @param idGaleria
     * @return
     * @throws DAOException 
     */
    @Override
    public Galeria obtener(Integer idGaleria) throws DAOException {
        //Galeria a retornar
        Galeria miGaleria = null;
        
        try {
            //Creamos la conexión a la base de datos
            conn = Conectar.realizarConexion();
            
            //Preparamos la consulta especificando sus parámetros
            ps = conn.prepareStatement(GETONE);
            ps.setInt(1, idGaleria);
            
            //Ejecutamos la consulta y almacenamos en un objeto ResultSet
            rs = ps.executeQuery();
            
            /*
            Verificamos si el ResultSet obtuvo un resultado y lo asignamos al objeto
            correspondiente
            */
            if (rs.next()) {
                miGaleria = new Galeria();
                miGaleria.setIdGaleria(rs.getInt("idGaleria"));
                miGaleria.setNombreGaleria(rs.getString("nombreGaleria"));
                miGaleria.setCalle(rs.getString("calle"));
                miGaleria.setColonia(rs.getString("colonia"));
                miGaleria.setCiudad(rs.getString("ciudad"));
                miGaleria.setEstado(rs.getString("estado"));
                miGaleria.setPais(rs.getString("pais"));
                miGaleria.setCodigoPostal(rs.getInt("codigoPostal"));
            }else {
                throw new DAOException ("No se encontro la galería");
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error de SQL: ", ex);
        }finally {
            cerrarConexiones(ps, rs, conn);
        }//Fin del finally
        
        return miGaleria;
    }//Fin del método obtener
    
    private void cerrarConexiones 
        (PreparedStatement ps, ResultSet rs, Connection conn) throws DAOException {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }catch (SQLException ex) {
            throw new DAOException ("Error en SQL", ex);
        }
    }//Fin del método cerrarConexiones
    
}//Fin de la clase MySQLGaleriaDAO
