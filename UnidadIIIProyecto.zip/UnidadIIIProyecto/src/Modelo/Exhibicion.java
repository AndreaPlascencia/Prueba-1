/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Andrea Plascencia
 */
public class Exhibicion {
    
    //Campos o propiedades
    private int idObra;
    private int idExposicion;
    
    //Constructor sin parámetros
    public Exhibicion () {
        
    }
    
    //Constructor con dos parámetros
    public Exhibicion (int idObra, int idExposicion) {
        this.setIdObra(idObra);
        this.setIdExposicion(idExposicion);
    }
    
    //Descriptores de acceso

    /**
     * @return the idObra
     */
    public int getIdObra() {
        return idObra;
    }

    /**
     * @param idObra the idObra to set
     */
    public void setIdObra(int idObra) {
        this.idObra = idObra;
    }

    /**
     * @return the idExposicion
     */
    public int getIdExposicion() {
        return idExposicion;
    }

    /**
     * @param idExposicion the idExposicion to set
     */
    public void setIdExposicion(int idExposicion) {
        this.idExposicion = idExposicion;
    }
     
}//Fin de la clase Exhibicion
