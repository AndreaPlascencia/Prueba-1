/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Andrea Plascencia
 */
public class Obra {
    
    //Campos o propiedades
    private int idObra;
    private int idAutor;
    private String tituloObra;
    private String corrienteArtistica;
    private String tecnica;
    private String anio;
    
    //Constructor sin parámetros
    public Obra () {
        
    }
    
    //Constructor con cinco parámetros
    public Obra (int idAutor, String tituloObra, 
            String corrienteArtistica, String tecnica, String anio) {
        this.setIdAutor(idAutor);
        this.setTituloObra(tituloObra);
        this.setCorrienteArtistica(corrienteArtistica);
        this.setTecnica(tecnica);
        this.setAnio(anio);
    }
    
    //Constructor con seis parámetros
    public Obra (int idObra, int idAutor, String tituloObra, 
            String corrienteArtistica, String tecnica, String anio) {
        this.setIdObra(idObra);
        this.setIdAutor(idAutor);
        this.setTituloObra(tituloObra);
        this.setCorrienteArtistica(corrienteArtistica);
        this.setTecnica(tecnica);
        this.setAnio(anio);
    }
    
    //Descriptores de acceso

    /**
     * @return the idObra
     */
    public int getIdObra() {
        return idObra;
    }

    /**
     * @param idObra the idObra to set
     */
    public void setIdObra(int idObra) {
        this.idObra = idObra;
    }

    /**
     * @return the idAutor
     */
    public int getIdAutor() {
        return idAutor;
    }

    /**
     * @param idAutor the idAutor to set
     */
    public void setIdAutor(int idAutor) {
        this.idAutor = idAutor;
    }

    /**
     * @return the tituloObra
     */
    public String getTituloObra() {
        return tituloObra;
    }

    /**
     * @param tituloObra the tituloObra to set
     */
    public void setTituloObra(String tituloObra) {
        this.tituloObra = tituloObra;
    }

    /**
     * @return the corrienteArtistica
     */
    public String getCorrienteArtistica() {
        return corrienteArtistica;
    }

    /**
     * @param corrienteArtistica the corrienteArtistica to set
     */
    public void setCorrienteArtistica(String corrienteArtistica) {
        this.corrienteArtistica = corrienteArtistica;
    }

    /**
     * @return the tecnica
     */
    public String getTecnica() {
        return tecnica;
    }

    /**
     * @param tecnica the tecnica to set
     */
    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }

    /**
     * @return the anio
     */
    public String getAnio() {
        return anio;
    }

    /**
     * @param anio the anio to set
     */
    public void setAnio(String anio) {
        this.anio = anio;
    }
    
}//Fin de la clase Obra
